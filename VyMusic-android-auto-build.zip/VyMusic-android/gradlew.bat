@echo off
where gradle >nul 2>nul
if %errorlevel%==0 (gradle %*) else (echo Install Gradle 8.7+ atau gunakan gradlew di Linux/Mac/CI & exit /b 1)
