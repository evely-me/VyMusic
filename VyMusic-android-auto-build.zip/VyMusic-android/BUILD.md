# VyMusic - Android project (WebView)

## Build otomatis (GitHub Actions)
1. Upload/push seluruh isi project ini ke repository GitHub.
2. Buka tab **Actions** pada repository.
3. Pilih workflow **Build APK**.
4. Klik **Run workflow** (atau lakukan push ke branch `main`/`master`).
5. Setelah status build berhasil, buka hasil workflow dan unduh artifact **VyMusic-APK**.
6. Ekstrak ZIP artifact, lalu install `app-debug.apk` di perangkat Android.

Workflow akan menyiapkan Java 17, Android SDK platform 34, dan Gradle 8.7 secara otomatis.

## Build manual
Syarat: JDK 17, Android SDK platform 34, dan Gradle 8.7. Jalankan:

    gradle assembleDebug

Hasil: `app/build/outputs/apk/debug/app-debug.apk`

Web app ada di `app/src/main/assets/www/`. Edit file di folder tersebut lalu build ulang.

**Catatan:** APK debug ditandatangani dengan debug key dan cocok untuk pengujian/instalasi pribadi, bukan untuk publikasi resmi di Play Store.
