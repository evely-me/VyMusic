/**
 * VyMusic Service Worker
 * Membuat aplikasi bisa di-install & bekerja offline (cache shell)
 */

const CACHE_NAME = 'vymusic-v1';
const ASSETS = [
  './',
  './index.html',
  './css/styles.css',
  './js/data.js',
  './js/player.js',
  './js/app.js',
  './manifest.json',
  './assets/icons/icon-192.png',
  './assets/icons/icon-512.png',
  './assets/icons/favicon.png'
];

// Install — cache core files
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS);
    }).then(() => self.skipWaiting())
  );
});

// Activate — hapus cache lama
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch — network first, fallback ke cache
self.addEventListener('fetch', (event) => {
  // Skip non-GET & cross-origin audio (biar streaming tetap jalan)
  if (event.request.method !== 'GET') return;

  const url = new URL(event.request.url);

  // Audio dari domain luar: biarkan browser handle
  if (url.hostname.includes('soundhelix.com') || 
      url.hostname.includes('picsum.photos') ||
      url.hostname.includes('cdnjs') ||
      url.hostname.includes('googleapis') ||
      url.hostname.includes('gstatic')) {
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cached) => {
      const fetchPromise = fetch(event.request)
        .then((response) => {
          // Cache response baru (jika sukses)
          if (response && response.status === 200 && response.type === 'basic') {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) => {
              cache.put(event.request, clone);
            });
          }
          return response;
        })
        .catch(() => cached); // offline → pakai cache

      return cached || fetchPromise;
    })
  );
});
