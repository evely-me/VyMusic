/**
 * VyMusic Player Engine
 * Modular — mudah diganti dengan Spotify Web Playback SDK nanti.
 */

class VyPlayer {
  constructor() {
    this.audio = document.getElementById("audio");
    this.queue = [];
    this.currentIndex = -1;
    this.isPlaying = false;
    this.isShuffle = false;
    this.repeatMode = 0; // 0=off, 1=all, 2=one
    this.volume = 0.8;
    this.liked = new Set();

    this.audio.volume = this.volume;

    this._bindEvents();
  }

  _bindEvents() {
    this.audio.addEventListener("timeupdate", () => this._onTimeUpdate());
    this.audio.addEventListener("ended", () => this._onEnded());
    this.audio.addEventListener("loadedmetadata", () => this._onLoaded());
    this.audio.addEventListener("play", () => {
      this.isPlaying = true;
      this._updatePlayButton();
    });
    this.audio.addEventListener("pause", () => {
      this.isPlaying = false;
      this._updatePlayButton();
    });
  }

  loadQueue(trackIds, startIndex = 0) {
    this.queue = trackIds.map((id) => getTrackById(id)).filter(Boolean);
    this.currentIndex = startIndex;
    if (this.queue.length) this._loadCurrent();
  }

  playTrack(trackId) {
    const track = getTrackById(trackId);
    if (!track) return;

    // Jika belum ada di queue, buat queue dari semua tracks
    if (!this.queue.length) {
      this.queue = [...VY_DATA.tracks];
    }

    const idx = this.queue.findIndex((t) => t.id === trackId);
    if (idx >= 0) {
      this.currentIndex = idx;
    } else {
      this.queue.push(track);
      this.currentIndex = this.queue.length - 1;
    }

    this._loadCurrent();
    this.play();
  }

  _loadCurrent() {
    const track = this.queue[this.currentIndex];
    if (!track) return;

    this.audio.src = track.audio;
    this.audio.load();

    // Update UI
    document.getElementById("player-cover").src = track.cover;
    document.getElementById("player-title").textContent = track.title;
    document.getElementById("player-artist").textContent = track.artist;

    document.getElementById("np-cover").src = track.cover;
    document.getElementById("np-title").textContent = track.title;
    document.getElementById("np-artist").textContent = track.artist;

    this._renderLyrics(track.lyrics || []);
    this._highlightPlayingRow(track.id);
    this._updateLikeButton(track.id);

    // Update document title
    document.title = `${track.title} • ${track.artist} — VyMusic`;
  }

  play() {
    this.audio.play().catch((e) => {
      console.warn("Autoplay blocked or error:", e);
    });
  }

  pause() {
    this.audio.pause();
  }

  togglePlay() {
    if (this.isPlaying) this.pause();
    else {
      if (this.currentIndex < 0 && this.queue.length === 0) {
        // default play first track
        this.loadQueue(VY_DATA.tracks.map((t) => t.id), 0);
      }
      this.play();
    }
  }

  next() {
    if (!this.queue.length) return;

    if (this.isShuffle) {
      this.currentIndex = Math.floor(Math.random() * this.queue.length);
    } else {
      this.currentIndex = (this.currentIndex + 1) % this.queue.length;
    }
    this._loadCurrent();
    this.play();
  }

  prev() {
    if (!this.queue.length) return;

    if (this.audio.currentTime > 3) {
      this.audio.currentTime = 0;
      return;
    }

    this.currentIndex =
      (this.currentIndex - 1 + this.queue.length) % this.queue.length;
    this._loadCurrent();
    this.play();
  }

  seek(percent) {
    if (!this.audio.duration) return;
    this.audio.currentTime = percent * this.audio.duration;
  }

  setVolume(vol) {
    this.volume = Math.max(0, Math.min(1, vol));
    this.audio.volume = this.volume;
    this._updateVolumeUI();
  }

  toggleShuffle() {
    this.isShuffle = !this.isShuffle;
    document.getElementById("btn-shuffle").classList.toggle("active", this.isShuffle);
  }

  cycleRepeat() {
    this.repeatMode = (this.repeatMode + 1) % 3;
    const btn = document.getElementById("btn-repeat");
    btn.classList.toggle("active", this.repeatMode > 0);
    btn.title =
      this.repeatMode === 0
        ? "Ulangi"
        : this.repeatMode === 1
        ? "Ulangi semua"
        : "Ulangi satu lagu";
  }

  toggleLike(trackId) {
    if (this.liked.has(trackId)) this.liked.delete(trackId);
    else this.liked.add(trackId);
    this._updateLikeButton(trackId);
  }

  // --- Internal ---
  _onTimeUpdate() {
    const cur = this.audio.currentTime;
    const dur = this.audio.duration || 0;
    const pct = dur ? (cur / dur) * 100 : 0;

    document.getElementById("progress-fill").style.width = pct + "%";
    document.getElementById("progress-thumb").style.left = pct + "%";
    document.getElementById("current-time").textContent = formatTime(cur);

    this._syncLyrics(cur);
  }

  _onLoaded() {
    document.getElementById("duration").textContent = formatTime(
      this.audio.duration
    );
  }

  _onEnded() {
    if (this.repeatMode === 2) {
      this.audio.currentTime = 0;
      this.play();
    } else if (this.repeatMode === 1 || this.currentIndex < this.queue.length - 1) {
      this.next();
    } else {
      this.isPlaying = false;
      this._updatePlayButton();
    }
  }

  _updatePlayButton() {
    const icon = document.getElementById("play-icon");
    icon.className = this.isPlaying ? "fa-solid fa-pause" : "fa-solid fa-play";
  }

  _updateVolumeUI() {
    document.getElementById("volume-fill").style.width = this.volume * 100 + "%";
    const icon = document.getElementById("vol-icon");
    if (this.volume === 0) icon.className = "fa-solid fa-volume-xmark";
    else if (this.volume < 0.4) icon.className = "fa-solid fa-volume-low";
    else icon.className = "fa-solid fa-volume-high";
  }

  _updateLikeButton(trackId) {
    const btn = document.getElementById("btn-like");
    const isLiked = this.liked.has(trackId);
    btn.classList.toggle("liked", isLiked);
    btn.querySelector("i").className = isLiked
      ? "fa-solid fa-heart"
      : "fa-regular fa-heart";
  }

  _highlightPlayingRow(trackId) {
    document.querySelectorAll(".track-row").forEach((row) => {
      row.classList.toggle("playing", row.dataset.id === trackId);
    });
  }

  _renderLyrics(lyrics) {
    const container = document.getElementById("lyrics-content");
    if (!lyrics || !lyrics.length) {
      container.innerHTML =
        '<p class="lyrics-line" style="color:var(--text-muted)">Lirik belum tersedia untuk lagu ini.</p>';
      return;
    }
    container.innerHTML = lyrics
      .map(
        (l, i) =>
          `<div class="lyrics-line" data-time="${l.time}" data-idx="${i}">${l.text}</div>`
      )
      .join("");
  }

  _syncLyrics(currentTime) {
    const lines = document.querySelectorAll(".lyrics-line[data-time]");
    let activeIdx = -1;
    lines.forEach((line, i) => {
      const t = parseFloat(line.dataset.time);
      if (currentTime >= t) activeIdx = i;
    });
    lines.forEach((line, i) => {
      line.classList.toggle("active", i === activeIdx);
    });
    // auto scroll ke baris aktif
    if (activeIdx >= 0) {
      const active = lines[activeIdx];
      if (active) {
        active.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    }
  }

  get currentTrack() {
    return this.queue[this.currentIndex] || null;
  }
}

// Global instance
window.vyPlayer = new VyPlayer();
