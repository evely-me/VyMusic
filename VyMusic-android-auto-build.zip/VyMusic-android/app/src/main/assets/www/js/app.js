/**
 * VyMusic — App UI Controller
 * Siap dikembangkan: ganti mock data dengan API, tambah routing, auth, dll.
 */

document.addEventListener("DOMContentLoaded", () => {
  initGreeting();
  renderHome();
  renderSearchGenres();
  renderLibrary();
  bindNavigation();
  bindPlayerControls();
  bindSearch();
  bindProgressAndVolume();
  bindNowPlaying();
});

/* ---------- Greeting ---------- */
function initGreeting() {
  const h = new Date().getHours();
  let text = "Selamat malam";
  if (h >= 5 && h < 11) text = "Selamat pagi";
  else if (h >= 11 && h < 15) text = "Selamat siang";
  else if (h >= 15 && h < 18) text = "Selamat sore";
  document.getElementById("greeting-text").textContent = text;
}

/* ---------- Render Home ---------- */
function renderHome() {
  // Quick cards
  const quick = document.querySelector(".quick-cards");
  const quickItems = [
    ...VY_DATA.playlists.slice(0, 4),
    { name: "Lagu Disukai", cover: "https://picsum.photos/seed/liked/100/100" },
    { name: "Discover Weekly", cover: "https://picsum.photos/seed/discover/100/100" },
  ];
  quick.innerHTML = quickItems
    .map(
      (p) => `
    <div class="quick-card" data-playlist="${p.id || ""}">
      <img src="${p.cover}" alt="" loading="lazy" />
      <span>${p.name}</span>
    </div>`
    )
    .join("");

  quick.querySelectorAll(".quick-card").forEach((card) => {
    card.addEventListener("click", () => {
      const pid = card.dataset.playlist;
      if (pid) {
        const pl = VY_DATA.playlists.find((p) => p.id === pid);
        if (pl) vyPlayer.loadQueue(pl.tracks, 0), vyPlayer.play();
      }
    });
  });

  // Made for you
  const made = document.getElementById("made-for-you");
  made.innerHTML = VY_DATA.tracks
    .slice(0, 6)
    .map(
      (t) => `
    <div class="music-card" data-id="${t.id}">
      <img class="cover" src="${t.cover}" alt="${t.title}" loading="lazy" />
      <div class="title">${t.title}</div>
      <div class="subtitle">${t.artist}</div>
    </div>`
    )
    .join("");

  made.querySelectorAll(".music-card").forEach((card) => {
    card.addEventListener("click", () => vyPlayer.playTrack(card.dataset.id));
  });

  // Artists
  const artists = document.getElementById("popular-artists");
  artists.innerHTML = VY_DATA.artists
    .map(
      (a) => `
    <div class="music-card" data-artist="${a.id}">
      <img class="cover" src="${a.image}" alt="${a.name}" loading="lazy" />
      <div class="title">${a.name}</div>
      <div class="subtitle">Artis • ${a.followers}</div>
    </div>`
    )
    .join("");

  // Recent tracks
  const recent = document.getElementById("recent-tracks");
  recent.innerHTML = VY_DATA.tracks
    .map(
      (t, i) => `
    <div class="track-row" data-id="${t.id}">
      <div class="idx">${i + 1}</div>
      <div class="track-meta">
        <img src="${t.cover}" alt="" loading="lazy" />
        <div class="info">
          <div class="t-title">${t.title}</div>
          <div class="t-artist">${t.artist}</div>
        </div>
      </div>
      <div class="track-album">${t.album}</div>
      <div class="track-duration">${formatTime(t.duration)}</div>
    </div>`
    )
    .join("");

  recent.querySelectorAll(".track-row").forEach((row) => {
    row.addEventListener("click", () => vyPlayer.playTrack(row.dataset.id));
  });
}

/* ---------- Search ---------- */
function renderSearchGenres() {
  const grid = document.getElementById("genres-grid");
  grid.innerHTML = VY_DATA.genres
    .map(
      (g) => `
    <div class="genre-card" style="background: ${g.color}">
      ${g.name}
    </div>`
    )
    .join("");
}

function bindSearch() {
  const input = document.getElementById("search-input");
  const results = document.getElementById("search-results");
  const list = document.getElementById("search-track-list");
  const genres = document.getElementById("genres-grid");

  input.addEventListener("input", () => {
    const q = input.value.trim().toLowerCase();
    if (!q) {
      results.classList.add("hidden");
      genres.classList.remove("hidden");
      return;
    }

    genres.classList.add("hidden");
    results.classList.remove("hidden");

    const matched = VY_DATA.tracks.filter(
      (t) =>
        t.title.toLowerCase().includes(q) ||
        t.artist.toLowerCase().includes(q) ||
        t.album.toLowerCase().includes(q)
    );

    list.innerHTML =
      matched.length === 0
        ? `<p style="color:var(--text-secondary);padding:20px">Tidak ada hasil untuk “${input.value}”</p>`
        : matched
            .map(
              (t, i) => `
        <div class="track-row" data-id="${t.id}">
          <div class="idx">${i + 1}</div>
          <div class="track-meta">
            <img src="${t.cover}" alt="" />
            <div class="info">
              <div class="t-title">${t.title}</div>
              <div class="t-artist">${t.artist}</div>
            </div>
          </div>
          <div class="track-album">${t.album}</div>
          <div class="track-duration">${formatTime(t.duration)}</div>
        </div>`
            )
            .join("");

    list.querySelectorAll(".track-row").forEach((row) => {
      row.addEventListener("click", () => vyPlayer.playTrack(row.dataset.id));
    });
  });

  // Focus search when clicking search nav
  document.querySelector('[data-view="search"]').addEventListener("click", () => {
    setTimeout(() => input.focus(), 100);
  });
}

/* ---------- Library ---------- */
function renderLibrary() {
  const list = document.getElementById("library-list");
  list.innerHTML = VY_DATA.playlists
    .map(
      (p) => `
    <div class="library-item" data-playlist="${p.id}">
      <img src="${p.cover}" alt="" />
      <div>
        <div class="lib-title">${p.name}</div>
        <div class="lib-sub">Playlist • ${p.tracks.length} lagu</div>
      </div>
    </div>`
    )
    .join("");

  list.querySelectorAll(".library-item").forEach((item) => {
    item.addEventListener("click", () => {
      const pl = VY_DATA.playlists.find((p) => p.id === item.dataset.playlist);
      if (pl) {
        vyPlayer.loadQueue(pl.tracks, 0);
        vyPlayer.play();
      }
    });
  });
}

/* ---------- Navigation ---------- */
function bindNavigation() {
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.addEventListener("click", (e) => {
      e.preventDefault();
      const view = item.dataset.view;

      document.querySelectorAll(".nav-item").forEach((n) => n.classList.remove("active"));
      item.classList.add("active");

      document.querySelectorAll(".view").forEach((v) => v.classList.remove("active"));
      const target = document.getElementById(`view-${view}`);
      if (target) target.classList.add("active");

      // close nowplaying if open
      document.getElementById("view-nowplaying").classList.remove("active");
    });
  });

  // Playlist sidebar clicks
  document.querySelectorAll(".playlist-item").forEach((item) => {
    item.addEventListener("click", () => {
      const key = item.dataset.playlist;
      const pl = VY_DATA.playlists.find((p) =>
        p.name.toLowerCase().includes(key) || p.id.includes(key)
      );
      if (pl) {
        vyPlayer.loadQueue(pl.tracks, 0);
        vyPlayer.play();
      }
    });
  });
}

/* ---------- Player Controls ---------- */
function bindPlayerControls() {
  document.getElementById("btn-play").addEventListener("click", () => vyPlayer.togglePlay());
  document.getElementById("btn-prev").addEventListener("click", () => vyPlayer.prev());
  document.getElementById("btn-next").addEventListener("click", () => vyPlayer.next());
  document.getElementById("btn-shuffle").addEventListener("click", () => vyPlayer.toggleShuffle());
  document.getElementById("btn-repeat").addEventListener("click", () => vyPlayer.cycleRepeat());

  document.getElementById("btn-like").addEventListener("click", () => {
    const t = vyPlayer.currentTrack;
    if (t) vyPlayer.toggleLike(t.id);
  });

  document.getElementById("btn-lyrics").addEventListener("click", () => {
    openNowPlaying();
  });
}

/* ---------- Progress & Volume ---------- */
function bindProgressAndVolume() {
  const progressBar = document.getElementById("progress-bar");
  progressBar.addEventListener("click", (e) => {
    const rect = progressBar.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    vyPlayer.seek(pct);
  });

  // drag support
  let dragging = false;
  progressBar.addEventListener("mousedown", () => (dragging = true));
  document.addEventListener("mouseup", () => (dragging = false));
  document.addEventListener("mousemove", (e) => {
    if (!dragging) return;
    const rect = progressBar.getBoundingClientRect();
    const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    vyPlayer.seek(pct);
  });

  // Volume
  const volBar = document.getElementById("volume-bar");
  volBar.addEventListener("click", (e) => {
    const rect = volBar.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    vyPlayer.setVolume(pct);
  });

  document.getElementById("btn-volume").addEventListener("click", () => {
    if (vyPlayer.volume > 0) {
      vyPlayer._lastVol = vyPlayer.volume;
      vyPlayer.setVolume(0);
    } else {
      vyPlayer.setVolume(vyPlayer._lastVol || 0.8);
    }
  });

  // init volume UI
  vyPlayer._updateVolumeUI();
}

/* ---------- Now Playing Overlay ---------- */
function bindNowPlaying() {
  document.getElementById("open-nowplaying").addEventListener("click", openNowPlaying);
  document.getElementById("close-nowplaying").addEventListener("click", closeNowPlaying);
}

function openNowPlaying() {
  document.querySelectorAll(".view").forEach((v) => v.classList.remove("active"));
  document.getElementById("view-nowplaying").classList.add("active");
}

function closeNowPlaying() {
  document.getElementById("view-nowplaying").classList.remove("active");
  document.getElementById("view-home").classList.add("active");
  document.querySelectorAll(".nav-item").forEach((n) => n.classList.remove("active"));
  document.querySelector('[data-view="home"]').classList.add("active");
}

/* ---------- Keyboard shortcuts ---------- */
document.addEventListener("keydown", (e) => {
  if (e.target.tagName === "INPUT") return;
  if (e.code === "Space") {
    e.preventDefault();
    vyPlayer.togglePlay();
  } else if (e.code === "ArrowRight") vyPlayer.next();
  else if (e.code === "ArrowLeft") vyPlayer.prev();
});
